import firebase from "firebase/app"

var firebaseConfig = {
    apiKey: "AIzaSyDGGBvGOh7F0zcrHBr4e0HJCE5ywkGp6s4",
    authDomain: "expense-generater.firebaseapp.com",
    projectId: "expense-generater",
    storageBucket: "expense-generater.appspot.com",
    messagingSenderId: "340535405986",
    appId: "1:340535405986:web:c7ab39efebd2239e2816fb",
    measurementId: "G-ENT3963JDG"
};

firebase.initializeApp(firebaseConfig);
